<?php

class Waiter extends ActiveRecord\Model {

   public static $table_name = 'zarest_waiters';
}
