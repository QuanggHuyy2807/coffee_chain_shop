<?php

class Sale extends ActiveRecord\Model {

   public static $table_name = 'zarest_sales';

}
